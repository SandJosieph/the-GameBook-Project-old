package sand.josieph.gamebook.resources;

public class Managers {

}
