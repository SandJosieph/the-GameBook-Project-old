package sand.josieph.gamebook;

public class GameBook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
